<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>navbar</title>
</head>
<body>

<!-- itt csináljuk a menüsort hogy ne kelljen mindenhol-->
    <div class="navbar">
        <div class="icon">
            <div class="menu">
                <ul>
                    <li><a href="../html/Home.html">Home</a></li>
                    <li><a href="../html/AboutFungi.html">About Fungi</a></li>
                    <li><a href="../html/TypesofFungi.html">Types of Fungi</a></li>

                    <li><a href="../html/ImportanceofFungi.html">Importance of Fungi</a></li>
                    <li><a href="../html/LearningandResources.html">Learning and Resources</a></li>
                    <li><a href="../html/ContactUs.html">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </div>

</body>
</html>