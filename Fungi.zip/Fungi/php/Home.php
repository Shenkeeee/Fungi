<!--<! FUNGIIIII&ndash;&gt;-->

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Fungi</title>
    <link rel="stylesheet" href="../css/home.css">
    <link rel="icon" href="../img/icon.png"/>
</head>
<body>

<!--háttér cssben-->

    <div class="main">
        <?php
            include_once "../php/navbar.php"
        ?>

        <div class="content">

            <h1><span>FANTASTIC  <br> FUNGI</span> </h1>
         
			<h2></h2>
            <h2 class="par">Timea Nemet & Mate Subicz</h2>
        </div>
    </div>
    
</body>
</html>